from pymavlink import mavutil
import time

slave  = mavutil.mavlink_connection('tcp:192.168.100.13:5760')
master = mavutil.mavlink_connection('tcp:192.168.100.12:5760')

while master.recv_msg():
    pass
while slave.recv_msg():
    pass

master.wait_heartbeat(10)
slave.wait_heartbeat(10)
print("[SLAVE] Connected")

boot_time_ms = int(time.time() * 1000)  # 程序启动时间（毫秒）

def send_attitude_value(system, value, label, send_log):
    now_ms = int(time.time() * 1000)
    relative_time = now_ms - boot_time_ms
    send_log[label] = now_ms
    system.mav.named_value_float_send(
        relative_time,
        label[:10].encode('ascii'),
        value
    )

send_log = {}
pitch_m = roll_m = yaw_m = None
ts_m = {'pitch_m': 0, 'roll_m': 0, 'yaw_m': 0}

while True:
    msg = slave.recv_match(type='ATTITUDE', blocking=True, timeout=1)
    if msg:
        pitch, roll, yaw = msg.pitch, msg.roll, msg.yaw
        now_ms = int(time.time() * 1000)
        print(f"[SLAVE] Sending pitch: {pitch:.2f}, roll: {roll:.2f}, yaw: {yaw:.2f} at {now_ms} ms")
        send_attitude_value(master, pitch, "pitch_s", send_log)
        send_attitude_value(master, roll, "roll_s", send_log)
        send_attitude_value(master, yaw,  "yaw_s",  send_log)

    try:
        for _ in range(3):
            msg = slave.recv_match(type='NAMED_VALUE_FLOAT', blocking=True, timeout=0.5)
            if msg:
                now = int(time.time() * 1000)
                msg = msg.to_dict()
                name = msg['name']
                value = msg['value']
                send_time = boot_time_ms + msg['time_boot_ms']
                latency = now - send_time
                ts_m[name] = latency
                if name == 'pitch_m':
                    pitch_m = value
                elif name == 'roll_m':
                    roll_m = value
                elif name == 'yaw_m':
                    yaw_m = value

        if pitch_m is not None and roll_m is not None and yaw_m is not None:
            print(f"[SLAVE] Received pitch: {pitch_m:.2f} ({ts_m['pitch_m']} ms), "
                  f"roll: {roll_m:.2f} ({ts_m['roll_m']} ms), "
                  f"yaw: {yaw_m:.2f} ({ts_m['yaw_m']} ms) at {int(time.time() * 1000)} ms")
    except Exception as e:
        print("Slave error receiving from master:", e)

    time.sleep(1)
