import time
from pymavlink import mavutil

master = mavutil.mavlink_connection('tcp:192.168.100.12:5760')
slave  = mavutil.mavlink_connection('tcp:192.168.100.13:5760')

while master.recv_msg():
    pass
while slave.recv_msg():
    pass

master.wait_heartbeat(10)
slave.wait_heartbeat(10)
print("[MASTER] Connected")

boot_time_ms = int(time.time() * 1000)  # 程序启动时间（毫秒）

def send_attitude_value(system, value, label, send_log):
    now_ms = int(time.time() * 1000)
    relative_time = now_ms - boot_time_ms
    send_log[label] = now_ms  # 本地记录绝对时间用于打印
    system.mav.named_value_float_send(
        relative_time,
        label[:10].encode('ascii'),
        value
    )

send_log = {}
pitch_s = roll_s = yaw_s = None
ts_s = {'pitch_s': 0, 'roll_s': 0, 'yaw_s': 0}

while True:
    msg = master.recv_match(type='ATTITUDE', blocking=True, timeout=1)
    if msg:
        pitch, roll, yaw = msg.pitch, msg.roll, msg.yaw
        now_ms = int(time.time() * 1000)
        print(f"[MASTER] Sending pitch: {pitch:.2f}, roll: {roll:.2f}, yaw: {yaw:.2f} at {now_ms} ms")
        send_attitude_value(slave, pitch, "pitch_m", send_log)
        send_attitude_value(slave, roll, "roll_m", send_log)
        send_attitude_value(slave, yaw,  "yaw_m",  send_log)

    try:
        for _ in range(3):
            msg = master.recv_match(type='NAMED_VALUE_FLOAT', blocking=True, timeout=0.5)
            if msg:
                now = int(time.time() * 1000)
                msg = msg.to_dict()
                name = msg['name']
                value = msg['value']
                send_time = boot_time_ms + msg['time_boot_ms']
                latency = now - send_time
                ts_s[name] = latency
                if name == 'pitch_s':
                    pitch_s = value
                elif name == 'roll_s':
                    roll_s = value
                elif name == 'yaw_s':
                    yaw_s = value

        if pitch_s is not None and roll_s is not None and yaw_s is not None:
            print(f"[MASTER] Received pitch: {pitch_s:.2f} ({ts_s['pitch_s']} ms), "
                  f"roll: {roll_s:.2f} ({ts_s['roll_s']} ms), "
                  f"yaw: {yaw_s:.2f} ({ts_s['yaw_s']} ms) at {int(time.time() * 1000)} ms")
    except Exception as e:
        print("Master error receiving from slave:", e)

    time.sleep(1)
