#!/usr/bin/env python3
"""
tri_peer_six_fields_dual.py

Run one instance per UAV terminal. Each instance:
- self_url: receive own telemetry (e.g., udp:0.0.0.0:14600)
- inbox_url: a *separate* UDP listener to receive peers' NAMED_VALUE_FLOAT (e.g., udpin:0.0.0.0:15600)
- out (repeatable): udpout endpoints for peers' inbox ports
- Sends 6 fields: lat, lon, alt (AMSL m), spd (m/s), hdg (deg), id
- Prints both SEND (from self_url GPI) and RECV (from inbox_url NAMED_VALUE_FLOAT)

Example mapping:
  uav0: self_url=udp:0.0.0.0:14600, inbox_url=udpin:0.0.0.0:15600
  uav1: self_url=udp:0.0.0.0:14610, inbox_url=udpin:0.0.0.0:15610
  uav2: self_url=udp:0.0.0.0:14620, inbox_url=udpin:0.0.0.0:15620

Send targets from each UAV:
  uav0 -> udpout:127.0.0.1:15610, udpout:127.0.0.1:15620
  uav1 -> udpout:127.0.0.1:15600, udpout:127.0.0.1:15620
  uav2 -> udpout:127.0.0.1:15600, udpout:127.0.0.1:15610
"""
import math
import time
import argparse
from pymavlink import mavutil

BROADCAST_HZ = 1.0  # one packet per second

def deg1e7_to_deg(v):  # int -> deg
    return float(v) * 1e-7

def mm_to_m(v):  # int -> m
    return float(v) / 1000.0

def cms_to_ms(v):  # int -> m/s
    return float(v) / 100.0

def cdeg_to_deg(v):  # 0..35999 -> deg; 65535/unknown -> NaN
    if v is None:
        return float('nan')
    iv = int(v)
    if iv == 65535 or iv < 0:
        return float('nan')
    return float(iv) / 100.0

def send_named_value_float(conn, label: str, value: float):
    label = label[:10]
    conn.mav.named_value_float_send(
        int(time.time()),
        label.encode('ascii'),
        float(value),
    )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--name', required=True, help='uav0/uav1/uav2')
    ap.add_argument('--sysid', type=int, required=True)
    ap.add_argument('--self_url', required=True, help='e.g., udp:0.0.0.0:14600')
    ap.add_argument('--inbox_url', required=True, help='e.g., udpin:0.0.0.0:15600')
    ap.add_argument('--out', action='append', required=True, help='e.g., udpout:127.0.0.1:15610 (repeat)')
    args = ap.parse_args()

    prefix = args.name[:3]

    # Input A: own telemetry feed
    print(f"[{args.name}] Connecting SELF  -> {args.self_url}")
    self_conn = mavutil.mavlink_connection(args.self_url)
    self_conn.wait_heartbeat(timeout=20)
    print(f"[{args.name}] SELF heartbeat OK: sys={self_conn.target_system}, comp={self_conn.target_component}")

    # Input B: inbox for peer messages
    print(f"[{args.name}] Connecting INBOX -> {args.inbox_url}")
    inbox_conn = mavutil.mavlink_connection(args.inbox_url)
    # inbox may or may not provide a heartbeat depending on sender; don't block on it

    # Outputs
    out_conns = []
    for url in args.out:
        print(f"[{args.name}] Connecting OUT   -> {url}")
        out_conns.append(mavutil.mavlink_connection(url))

    last_tx = 0.0
    period = 1.0 / BROADCAST_HZ if BROADCAST_HZ > 0 else 0.0
    print(f"[{args.name}] Running. SEND @ {BROADCAST_HZ} Hz | printing SEND (self_url) + RECV (inbox_url). Ctrl+C to stop.")

    while True:
        now = time.time()

        # RECV path: print peers' NAMED_VALUE_FLOAT from inbox
        msg_in = inbox_conn.recv_match(blocking=False)
        if msg_in and msg_in.get_type() == 'NAMED_VALUE_FLOAT':
            d = msg_in.to_dict()
            try:
                name = (d.get('name') or b'').decode(errors='ignore')
            except AttributeError:
                name = str(d.get('name'))
            value = float(d.get('value', float('nan')))
            print(f"[RECV][{args.name}] {name} = {value}")

        # SEND path: pick up GLOBAL_POSITION_INT from self_conn and broadcast
        if now - last_tx >= period:
            # Try to fetch a fresh GPI quickly
            deadline = now + 0.05
            gpi = None
            while time.time() < deadline:
                m = self_conn.recv_match(blocking=False)
                if m and m.get_type() == 'GLOBAL_POSITION_INT':
                    gpi = m
                    break
                time.sleep(0.002)

            if gpi:
                gd = gpi.to_dict()
                lat = deg1e7_to_deg(gd.get('lat', 0))
                lon = deg1e7_to_deg(gd.get('lon', 0))
                alt_m = mm_to_m(gd.get('alt', 0))
                vx = gd.get('vx', 0)
                vy = gd.get('vy', 0)
                spd_ms = cms_to_ms((vx**2 + vy**2) ** 0.5)
                hdg = cdeg_to_deg(gd.get('hdg', None))
                uav_id = float(args.sysid)

                labels_values = [
                    (f"{prefix}_lat", lat),
                    (f"{prefix}_lon", lon),
                    (f"{prefix}_alt", alt_m),
                    (f"{prefix}_spd", spd_ms),
                    (f"{prefix}_hdg", hdg),
                    (f"{prefix}_id",  uav_id),
                ]

                for oc in out_conns:
                    for label, value in labels_values:
                        send_named_value_float(oc, label, value)

                print(f"[SEND][{args.name}] lat={lat:.6f}, lon={lon:.6f}, alt={alt_m:.1f} m, "
                      f"spd={spd_ms:.2f} m/s, hdg={hdg:.2f} deg, id={uav_id:.0f}")
                last_tx = time.time()

        time.sleep(0.002)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Stopped by user.")
