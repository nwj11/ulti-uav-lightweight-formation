#!/usr/bin/env python3
import math
import time
import argparse
from pymavlink import mavutil
from dataclasses import dataclass

EARTH_R = 6378137.0  # meters

@dataclass
class UAV:
    name: str
    sysid: int
    url: str     # tcp link to the vehicle (via MAVProxy tcpin)

def deg_to_rad(d): return d * math.pi / 180.0
def rad_to_deg(r): return r * 180.0 / math.pi

def add_meters_to_latlon(lat_deg, lon_deg, north_m, east_m):
    lat = deg_to_rad(lat_deg)
    dlat = north_m / EARTH_R
    dlon = east_m / (EARTH_R * math.cos(lat))
    return lat_deg + rad_to_deg(dlat), lon_deg + rad_to_deg(dlon)

def cdeg_to_deg(hdg_cdeg):
    if hdg_cdeg is None: return float('nan')
    v = int(hdg_cdeg)
    if v == 65535 or v < 0: return float('nan')
    return v / 100.0

def mm_to_m(v): return float(v) / 1000.0
def i1e7_to_deg(v): return float(v) * 1e-7

def send_pos_target_global(conn, target_sysid, lat_deg, lon_deg, alt_m):
    type_mask = 0b0000101111111000  # position-only
    # Use explicit target system; component 1 (autopilot)
    conn.mav.set_position_target_global_int_send(
        int(time.time() * 1000) & 0xFFFFFFFF,
        target_sysid, 1,
        mavutil.mavlink.MAV_FRAME_GLOBAL_INT,
        type_mask,
        int(lat_deg * 1e7),
        int(lon_deg * 1e7),
        float(alt_m),
        0,0,0,
        0,0,0,
        float('nan'),
        0.0
    )

def distance_horiz_m(lat1, lon1, lat2, lon2):
    latm = deg_to_rad((lat1 + lat2) / 2.0)
    dx = (deg_to_rad(lon2 - lon1)) * EARTH_R * math.cos(latm)
    dy = (deg_to_rad(lat2 - lat1)) * EARTH_R
    return math.hypot(dx, dy)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--side', type=float, default=40.0)
    ap.add_argument('--alt', type=float, default=132.0)  # AMSL for Durham example
    ap.add_argument('--speed', type=float, default=5.0)
    ap.add_argument('--trail', type=float, default=15.0)
    ap.add_argument('--spread', type=float, default=12.0)
    ap.add_argument('--warn', type=float, default=8.0)
    ap.add_argument('--hz', type=float, default=2.0)
    ap.add_argument('--src-base', type=int, default=240, help='source_system base for this script')
    args = ap.parse_args()

    # TCP ports (add --out=tcpin:0.0.0.0:9950/60/70 to your sim_vehicle lines)
    u0 = UAV('uav0', 1, 'tcp:127.0.0.1:9950')  # leader
    u1 = UAV('uav1', 2, 'tcp:127.0.0.1:9960')
    u2 = UAV('uav2', 3, 'tcp:127.0.0.1:9970')
    fleet = [u0, u1, u2]

    # Open links with unique source_system IDs to avoid clashing with QGC (255)
    links = {}
    for idx, u in enumerate(fleet):
        ss = args.src_base + idx  # 240,241,242
        print(f"[CTRLv3] Link {u.name} <-/-> {u.url} (src sysid={ss})")
        links[u.name] = mavutil.mavlink_connection(u.url, source_system=ss, source_component=191)
        links[u.name].wait_heartbeat(timeout=30)
        print(f"[CTRLv3] {u.name} heartbeat ok (veh sysid={links[u.name].target_system})")

    print("[CTRLv3] Ensure all vehicles are GUIDED + ARMED (QGC or MAVProxy).")

    # Reference from leader
    leader = u0
    print("[CTRLv3] Waiting for leader GLOBAL_POSITION_INT...")
    while True:
        m = links[leader.name].recv_match(type='GLOBAL_POSITION_INT', blocking=True, timeout=2.0)
        if not m: continue
        d = m.to_dict()
        lat0 = i1e7_to_deg(d['lat']); lon0 = i1e7_to_deg(d['lon']); alt0 = mm_to_m(d['alt'])
        break
    print(f"[CTRLv3] Leader ref lat={lat0:.7f}, lon={lon0:.7f}, alt={alt0:.1f}")

    half = args.side / 2.0
    square_local = [(+half, +half), (-half, +half), (-half, -half), (+half, -half)]
    wp_idx = 0
    target_lat, target_lon = add_meters_to_latlon(lat0, lon0, square_local[0][1], square_local[0][0])

    dt = 1.0 / max(0.5, args.hz)
    last_print = 0.0

    while True:
        m = links[leader.name].recv_match(type='GLOBAL_POSITION_INT', blocking=False)
        if not m:
            time.sleep(dt)
            continue
        d = m.to_dict()
        latL = i1e7_to_deg(d['lat']); lonL = i1e7_to_deg(d['lon']); altL = mm_to_m(d['alt'])
        hdgL = cdeg_to_deg(d.get('hdg'))

        # March leader toward wp
        dist_to_wp = distance_horiz_m(latL, lonL, target_lat, target_lon)
        if dist_to_wp < max(2.0, args.speed * 0.6):
            wp_idx = (wp_idx + 1) % 4
            ex, ny = square_local[wp_idx]
            target_lat, target_lon = add_meters_to_latlon(lat0, lon0, ny, ex)

        # step
        br = math.atan2(
            math.sin((target_lon - lonL) * math.pi/180.0) * math.cos(target_lat * math.pi/180.0),
            math.cos(latL * math.pi/180.0) * math.sin(target_lat * math.pi/180.0) -
            math.sin(latL * math.pi/180.0) * math.cos(target_lat * math.pi/180.0) * math.cos((target_lon - lonL) * math.pi/180.0)
        )
        step_n = args.speed * dt * math.cos(br)
        step_e = args.speed * dt * math.sin(br)
        next_lat, next_lon = add_meters_to_latlon(latL, lonL, step_n, step_e)

        send_pos_target_global(links[leader.name], leader.sysid, next_lat, next_lon, args.alt)

        # followers
        if math.isnan(hdgL):
            hdg_rad = br
        else:
            hdg_rad = hdgL * math.pi/180.0
        fn = math.cos(hdg_rad); fe = math.sin(hdg_rad)
        rn = fe; re = -fn
        back = args.trail
        side = args.spread/2.0

        n1 = -side*rn - back*fn; e1 = -side*re - back*fe
        f1_lat, f1_lon = add_meters_to_latlon(latL, lonL, n1, e1)
        send_pos_target_global(links['uav1'], u1.sysid, f1_lat, f1_lon, args.alt)

        n2 = +side*rn - back*fn; e2 = +side*re - back*fe
        f2_lat, f2_lon = add_meters_to_latlon(latL, lonL, n2, e2)
        send_pos_target_global(links['uav2'], u2.sysid, f2_lat, f2_lon, args.alt)

        # warn (fetch freshest follower positions)
        pos = {'uav0': (latL, lonL)}
        m1 = links['uav1'].recv_match(type='GLOBAL_POSITION_INT', blocking=False)
        if m1:
            d1 = m1.to_dict(); pos['uav1'] = (i1e7_to_deg(d1['lat']), i1e7_to_deg(d1['lon']))
        m2 = links['uav2'].recv_match(type='GLOBAL_POSITION_INT', blocking=False)
        if m2:
            d2 = m2.to_dict(); pos['uav2'] = (i1e7_to_deg(d2['lat']), i1e7_to_deg(d2['lon']))

        names = list(pos.keys())
        for i in range(len(names)):
            for j in range(i+1, len(names)):
                a, b = names[i], names[j]
                latA, lonA = pos[a]; latB, lonB = pos[b]
                dist = distance_horiz_m(latA, lonA, latB, lonB)
                if dist < args.warn:
                    print(f"[WARN] {a} <-> {b} too close: {dist:.1f} m")

        now = time.time()
        if now - last_print > 2.0:
            last_print = now
            print(f"[CTRLv3] Leader->({next_lat:.6f},{next_lon:.6f}) wp#{wp_idx} | f1({f1_lat:.6f},{f1_lon:.6f}) f2({f2_lat:.6f},{f2_lon:.6f})")

        time.sleep(dt)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[CTRLv3] Stopped by user.")
