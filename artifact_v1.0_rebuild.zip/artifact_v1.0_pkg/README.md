# Multi-UAV Lightweight Exchange & Formation — Artifact v1.0
This package contains real-system and simulation scripts, plus minimal environment files.
